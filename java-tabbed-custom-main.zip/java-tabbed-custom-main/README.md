# java-tabbed-custom
custom tabbed pane ui using java swing

![2023-04-21_010631](https://user-images.githubusercontent.com/58245926/233840857-ce9c65f0-9060-4372-a2fc-53776b398308.png)
